"""
This module provides parameter generators for different kinds of parameters
"""
from param_injector.param_injector import ParamInjector
