"""
This module filters the search space for a specified parameter using a binary
search based heuristic
"""
from range_inference.range_inference import *
